from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Asosiy sahifa uchun URL
    path('category/create/', views.create_category, name='create_category'),
    path('category/update/<int:pk>/', views.update_category, name='update_category'),
    path('fooditem/create/', views.create_fooditem, name='create_fooditem'),
    path('fooditem/update/<int:pk>/', views.update_fooditem, name='update_fooditem'),
]
