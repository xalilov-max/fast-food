from django.shortcuts import render, redirect, get_object_or_404
from .models import Category, FoodItem
from .forms import CategoryForm, FoodItemForm

def home(request):
    return render(request, 'index.html')
    
def create_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm()
    return render(request, 'menu/category_form.html', {'form': form})

def update_category(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'menu/category_form.html', {'form': form})

def create_fooditem(request):
    if request.method == 'POST':
        form = FoodItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('fooditem_list')
    else:
        form = FoodItemForm()
    return render(request, 'menu/fooditem_form.html', {'form': form})

def update_fooditem(request, pk):
    fooditem = get_object_or_404(FoodItem, pk=pk)
    if request.method == 'POST':
        form = FoodItemForm(request.POST, request.FILES, instance=fooditem)
        if form.is_valid():
            form.save()
            return redirect('fooditem_list')
    else:
        form = FoodItemForm(instance=fooditem)
    return render(request, 'menu/fooditem_form.html', {'form': form})
